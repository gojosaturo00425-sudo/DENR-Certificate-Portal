<?php
require_once __DIR__ . '/../includes/config.php';
$token = trim($_GET['token'] ?? '');
$number = trim($_GET['certificate_no'] ?? '');
$certificate = null;
if ($token !== '' || $number !== '') {
    $lookup = $pdo->prepare("SELECT c.*,CONCAT(e.first_name,' ',e.last_name) employee_name,COALESCE(c.certificate_type,t.title,'Training Certificate') training_title FROM certificates c JOIN employees e ON e.id=c.employee_id LEFT JOIN trainings t ON t.id=c.training_id WHERE " . ($token !== '' ? 'c.qr_token=?' : 'c.certificate_no=?') . ' LIMIT 1');
    $lookup->execute([$token !== '' ? $token : $number]);
    $certificate = $lookup->fetch();
}
$valid = $certificate && in_array($certificate['status'], ['ACTIVE','APPROVED','EXPIRING'], true) && (!$certificate['valid_until'] || $certificate['valid_until'] >= date('Y-m-d'));
?>
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Verify Certificate - DENR XII</title><link rel="stylesheet" href="<?= BASE_URL ?>/assets/style.css"></head>
<body><div class="login panel">
<h1>DENR XII Certificate Verification</h1>
<form><div class="field"><label for="certificate_no">Certificate Number</label><input id="certificate_no" name="certificate_no" value="<?= htmlspecialchars($number) ?>" placeholder="DENRXII-2026-000184"></div><br><button class="btn">Verify</button></form>
<?php if ($certificate): ?><hr><h2><?= $valid ? '✓ VALID' : '✕ NOT VALID' ?></h2><p><strong>Certificate No.:</strong> <?= htmlspecialchars($certificate['certificate_no']) ?></p><p><strong>Employee:</strong> <?= htmlspecialchars($certificate['employee_name']) ?></p><p><strong>Training / Certificate Type:</strong> <?= htmlspecialchars($certificate['training_title']) ?></p><p><strong>Issued:</strong> <?= htmlspecialchars($certificate['issued_date'] ?? '-') ?></p><p><strong>Valid Until:</strong> <?= htmlspecialchars($certificate['valid_until'] ?? '-') ?></p><p><strong>Status:</strong> <?= htmlspecialchars($certificate['status']) ?></p>
<?php elseif ($token !== '' || $number !== ''): ?><div class="notice error">Certificate not found.</div><?php endif; ?>
</div></body></html>
